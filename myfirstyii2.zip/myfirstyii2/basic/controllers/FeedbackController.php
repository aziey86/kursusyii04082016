<?php
namespace app\controllers;
use Yii;

class FeedbackController extends \yii\web\Controller
{
    public function actionIndex()
    {
        return $this->render('index');
    }

    public function actionForm()
	{
	    $model = new \app\models\Feedback();

	    if ($model->load(Yii::$app->request->post())) {
	        if ($model->validate()) {
	            $model->storeTable(Yii::$app->request->post()['Feedback']);
        		return $this->render('form',['model'=>$model]);//('list',['bookModel'=>$model]);
	            //return;
	        }
	    }

	    return $this->render('form', [
	        'model' => $model,
	    ]);
	}

	// public function actionAdd()
	// {
 //      $feedbackModel = new feedback();
 //      $fbsubject = '';
 //      if($feedbackModel -> load(Yii::$app->request->post())){
 //        $feedbackModel->storeTable(Yii::$app->request->post()['feedback']);
 //        return $this->render('list',['feedbackModel'=>$feedbackModel]);
 //      }
 //      else{
 //      	return $this->render('add',['feedbackModel'=>$feedbackModel,'subject'=>$fbsubject]);
 //      }
 //    }

}
