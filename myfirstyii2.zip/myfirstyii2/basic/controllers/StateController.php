<?php 

namespace app\controllers;

use Yii;
use yii\web\Controller;
use app\models\State;

/**
* 
*/
class StateController extends Controller
{
	
	public function actionTable()
	{
		return $this->render('table');
	}
}

?>