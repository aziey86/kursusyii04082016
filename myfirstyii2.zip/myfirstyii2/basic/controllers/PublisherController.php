<?php

namespace app\controllers;

class PublisherController extends \yii\web\Controller
{
    public function actionIndex()
    {
        return $this->render('index');
    }

}
