<?php

namespace app\models;
use Yii;
use yii\db\Query;
use yii\db\ActiveRecord;
//use yii\base\Model;

class book extends ActiveRecord{

  // public $bookname;
  // public $publisher;
  // public $edition;
  // public $author;
  // public $price;
  // public $isbn;

  public static function tableName(){
      return "book";
  }

   public function attributeLabels()
   {
       return ["bookname" => "Book Name", //Assign Attribute
       "publisher" => "Publisher", //Assign Attribute
       "edition" => "Edition", //Assign Attribute
       "author" => "Author", //Assign Attribute
       "price" => "Price", //Assign Attribute
       "isbn" => "ISBN"];
   }

   public function rules()
    {
        return [
            // 'bookname', 'publisher','author','price' are both required
            [['bookname', 'author','price'], 'required']  //'publisher',
        ];
    }

    public function getListUseCommand(){
       // return a set of rows. each row is an associative array of column names and values.
       // an empty array is returned if the query returned no results
        $bookAll = Yii::$app->db->createCommand('SELECT * FROM book')
           ->queryAll();

        // return a single row (the first row)
        // false is returned if the query has no result
        $bookOne = Yii::$app->db->createCommand('SELECT * FROM book WHERE id=1')
           ->queryOne();

        // return a single column (the first column)
        // an empty array is returned if the query returned no results
        $bookColumn = Yii::$app->db->createCommand('SELECT bookname FROM book')
           ->queryColumn();

        // return a scalar value
        // false is returned if the query has no result
        $bookScalar = Yii::$app->db->createCommand('SELECT COUNT(*) FROM book')
           ->queryScalar();

        return $bookAll;
    }

    public function getTableList()
    {
       //$book = (new Query())->select('*')->from('book')->where('id=1 or bookname="PHP"')->all(); 
       $book = (new Query())->select('*')->from('book')->all(); 
       return $book;
    }

    public function storeTable($bookArray){

     $book = new book();
     $book->bookname = $bookArray['bookname'];
     $book->publisher = $bookArray['publisher'];
     $book->edition = $bookArray['edition'];
     $book->author = $bookArray['author'];
     $book->price = $bookArray['price'];
     $book->isbn = $bookArray['isbn'];
     $book->save();

  }

  public function updateTable($id, $bookArray){
     $book = book::findOne($id);
     $book->bookname = $bookArray['book']['bookname'];
     $book->publisher = $bookArray['book']['publisher'];
     $book->edition = $bookArray['book']['edition'];
     $book->author = $bookArray['book']['author'];
     $book->price = $bookArray['book']['price'];
     $book->isbn = $bookArray['book']['isbn'];
     $book->save();
  }

  public function deleteTable($id){
     $book = book::findOne($id);
     $book->delete();
  }
    
}


?>
