<?php

namespace app\models;

use yii\base\Model;

class State extends Model{

   function getStates(){
    return array("Selangor", "Johor", "Kedah", "Kelantan", "Melaka", "Negeri Sembilan", "Pahang", "Perak", "Perlis", "Pulau Pinang", "Sabah", "Sarawak", "Terengganu");
  }
  function getibus(){
    return array("Shah Alam", "Johor Bahru", "Alor Setar", "Kota Bahru", "Bandar Melaka", "Seremban", "Kuantan", "Ipoh", "Kangar", "Georgetown", "Kota Kinabalu", "Kuching", "Kuala Terengganu");
  }
  function getshorts(){
    return array("SGR", "JHR", "KDH", "KTN", "MLK", "NSN", "PHG", "PRK", "PLS", "PNG", "SBH", "SWK", "TRG");    
    }

       
}
?>