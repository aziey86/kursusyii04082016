<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "company".
 *
 * @property integer $id
 * @property string $company_name
 * @property string $reg_num
 * @property string $business_type
 * @property string $business_owner
 */
class Company extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'company';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['company_name'], 'string', 'max' => 155],
            [['reg_num', 'business_type', 'business_owner'], 'string', 'max' => 50],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'company_name' => 'Company Name',
            'reg_num' => 'Reg Num',
            'business_type' => 'Business Type',
            'business_owner' => 'Business Owner',
        ];
    }
}
