<?php

namespace app\models;

use Yii;
use app\models\feedback;
/**
 * This is the model class for table "feedback".
 *
 * @property integer $id
 * @property string $subject
 * @property string $description
 * @property string $email
 * @property string $name
 */
class Feedback extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'feedback';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['subject'], 'string', 'max' => 150],
            [['description'], 'string', 'max' => 350],
            [['email'], 'string', 'max' => 50],
            [['name'], 'string', 'max' => 100],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'subject' => 'Subject',
            'description' => 'Description',
            'email' => 'Email',
            'name' => 'Name',
        ];
    }

    public function storeTable($fbArray){

     $feedback = new feedback();
     $feedback->subject = $fbArray['subject'];
     $feedback->description = $fbArray['description'];
     $feedback->email = $fbArray['email'];
     $feedback->name = $fbArray['name'];
     $feedback->save();

  }
}
