<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model \app\models\Feedback */
/* @var $form ActiveForm */
?>
<div class="feedback-form">

    <?php $form = ActiveForm::begin(); ?>

        <?= $form->field($model, 'subject') ?>
        <?= $form->field($model, 'description') ?>
        <?= $form->field($model, 'email') ?>
        <?= $form->field($model, 'name') ?>
    
        <div class="form-group">
            <?= Html::submitButton('Submit', ['class' => 'btn btn-primary']) ?>
        </div>
    <?php ActiveForm::end(); ?>

</div><!-- feedback-form -->
