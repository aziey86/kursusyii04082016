<?php

use app\models\State;

$this->title = 'State';
$this->params['breadcrumbs'][] = $this->title;;
$StateModel = new State;

$State = $StateModel->attributeLabels();

?>

<style>
.textbold{
	font-weight: bold;
}
</style>

<ul><strong>Malaysia States</strong>

<style>
table td, table th{
	text-align: center;
	padding: 5px 11px;
}
</style>

<table border = "3" cellspacing="0" cellpadding="0">
<tr>
	<TH>State Name</TH>
	<TH>Ibu Negeri</TH>
	<TH>Short Name</TH>
</tr>

<?php 
$num = 0;
$states = new State;
	foreach ($states->getStates() as $state) {
	if($states->getshorts()[$num]=="JHR"){
		$bold = "class='textbold'";
	}else{
		$bold = '';
	}
?>

<tr <?php echo $bold;?>> 
	<td><?php echo $state;?></td>
	<td><?php echo $states->getibus()[$num];?></td>
	<td><?php echo $states->getshorts()[$num];?></td>
</tr>
<?php 
$num++;
}?>
</table></ul>
<hr/>
<ul>*<b>Bold </b> state is the state you're living in.</ul>